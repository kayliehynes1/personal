# screens/lobby.py

import tkinter as tk
from typing import TYPE_CHECKING

from base import BaseScreen, RetroButton
from theme import FONT_TITLE, FONT_HEADER, FONT_BODY, FONT_SMALL

if TYPE_CHECKING:
    from client import App

DIFFICULTY_COLOURS = {
    "easy":   "#4caf50",
    "medium": "#ff9800",
    "hard":   "#f44336",
}


class LobbyScreen(BaseScreen):
    """Main lobby — shows puzzle list and navigation to all other screens."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        # Top bar
        bar = tk.Frame(self, bg=t["bg_secondary"], pady=8)
        bar.pack(fill="x")

        tk.Label(bar, text="SUDOKU", font=FONT_TITLE,
                 bg=t["bg_secondary"], fg=t["accent"]).pack(side="left", padx=16)

        self._user_label = tk.Label(bar, text="", font=FONT_SMALL,
                                    bg=t["bg_secondary"], fg=t["text_dim"])
        self._user_label.pack(side="right", padx=16)

        tk.Button(bar, text="☀ / ☾", font=FONT_SMALL, relief="flat",
                  bg=t["bg_secondary"], fg=t["text_dim"], cursor="hand2",
                  command=self.app.toggle_theme).pack(side="right", padx=4)

        # Nav buttons
        nav = tk.Frame(self, bg=t["bg"], pady=6)
        nav.pack(fill="x", padx=16)

        for label, screen in [
            ("+ ADD PUZZLE",  "AddPuzzleScreen"),
            ("MY STATS",      "StatsScreen"),
            ("LEADERBOARD",   "LeaderboardScreen"),
            ("SOCIAL",        "SocialScreen"),
        ]:
            RetroButton(nav, self.app, label,
                        command=lambda s=screen: self.app.show_frame(s)).pack(
                side="left", padx=6, pady=6)

        RetroButton(nav, self.app, "LOG OUT",
                    command=self._logout).pack(side="right", padx=6, pady=6)

        # Puzzle list header
        hdr = tk.Frame(self, bg=t["bg_secondary"])
        hdr.pack(fill="x", padx=16, pady=(8, 0))
        tk.Label(hdr, text="Puzzles", font=FONT_HEADER,
                 bg=t["bg_secondary"], fg=t["text"]).pack(side="left", padx=10, pady=6)
        RetroButton(hdr, self.app, "↺ REFRESH",
                    command=self._load_puzzles).pack(side="right", padx=8, pady=4)

        # Scrollable puzzle list
        list_frame = tk.Frame(self, bg=t["bg"])
        list_frame.pack(fill="both", expand=True, padx=16, pady=8)

        self._canvas = tk.Canvas(list_frame, bg=t["bg"], highlightthickness=0)
        scrollbar    = tk.Scrollbar(list_frame, orient="vertical",
                                    command=self._canvas.yview)
        self._inner  = tk.Frame(self._canvas, bg=t["bg"])

        self._inner.bind("<Configure>",
                         lambda e: self._canvas.configure(
                             scrollregion=self._canvas.bbox("all")))

        self._canvas.create_window((0, 0), window=self._inner, anchor="nw")
        self._canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._status = tk.Label(self, text="", font=FONT_SMALL,
                                bg=t["bg"], fg=t["text_dim"])
        self._status.pack(pady=4)

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._build()
        self._load_puzzles()

    def tkraise(self, *args) -> None:  # type: ignore[override]
        super().tkraise(*args)
        if self.app.username:
            self._user_label.config(text=f"👤 {self.app.username}")
        self._load_puzzles()

    def _load_puzzles(self) -> None:
        for w in self._inner.winfo_children():
            w.destroy()
        self._status.config(text="Loading…")

        # server returns {"status": "ok", "puzzles": [...]}
        result  = self.app.server.get_puzzles()
        puzzles = result.get("puzzles", []) if isinstance(result, dict) else []

        if not puzzles:
            self._status.config(text="No puzzles found — add one!")
            return

        self._status.config(text="")
        t = self.app.theme

        for p in puzzles:
            row = tk.Frame(self._inner, bg=t["bg_secondary"], pady=6, padx=10)
            row.pack(fill="x", pady=3)

            diff   = (p.get("difficulty") or "medium").lower()
            colour = DIFFICULTY_COLOURS.get(diff, t["text_dim"])
            author = p.get("author") or "unknown"
            label  = f"Puzzle #{p['id']}"

            tk.Label(row, text=label, font=FONT_BODY,
                     bg=t["bg_secondary"], fg=t["text"]).pack(side="left")
            tk.Label(row, text=f"  {diff}", font=FONT_SMALL,
                     bg=t["bg_secondary"], fg=colour).pack(side="left")
            tk.Label(row, text=f"  by {author}", font=FONT_SMALL,
                     bg=t["bg_secondary"], fg=t["text_dim"]).pack(side="left")

            RetroButton(row, self.app, "PLAY",
                        command=lambda pid=p["id"]: self._open_puzzle(pid)).pack(
                side="right", padx=4)

    def _open_puzzle(self, puzzle_id: int) -> None:
        self.app.current_puzzle_id = puzzle_id
        self.app.frames["PuzzleScreen"].load_puzzle(puzzle_id)
        self.app.show_frame("PuzzleScreen")

    def _logout(self) -> None:
        self.app.user_id         = None
        self.app.username        = None
        self.app.server.user_id  = None
        self.app.server.username = None
        self.app.show_frame("LoginScreen")
