# screens/puzzle.py

import time
import tkinter as tk
from typing import Optional, TYPE_CHECKING

from base import BaseScreen, RetroButton
from theme import FONT_HEADER, FONT_BODY, FONT_CELL, FONT_SMALL, FONT_BTN

if TYPE_CHECKING:
    from client import App

_GIVEN_FG = "#aaaacc"   # pre-filled clue colour
_USER_FG  = "#eaeaea"   # user-entered colour
_ERROR_BG = "#6b0f1a"   # wrong cell background after validate
_HINT_FG  = "#f5a623"   # hint cell colour


class PuzzleScreen(BaseScreen):
    """Interactive Sudoku grid with timer, hints, validation and submission."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._puzzle:     Optional[dict] = None
        self._cells:      list[tk.Label] = []
        self._given:      list[bool]     = []
        self._user_values: list[int]     = []
        self._selected:   Optional[int]  = None
        self._start_time: float          = 0.0
        self._timer_id:   Optional[str]  = None
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        # Top bar
        bar = tk.Frame(self, bg=t["bg_secondary"], pady=8)
        bar.pack(fill="x")
        RetroButton(bar, self.app, "← LOBBY",
                    command=self._back).pack(side="left", padx=10)
        self._title_label = tk.Label(bar, text="", font=FONT_HEADER,
                                     bg=t["bg_secondary"], fg=t["text"])
        self._title_label.pack(side="left", padx=16)
        self._timer_label = tk.Label(bar, text="00:00", font=FONT_HEADER,
                                     bg=t["bg_secondary"], fg=t["accent2"])
        self._timer_label.pack(side="right", padx=16)

        # Grid (centred)
        self._grid_frame = tk.Frame(self, bg=t["bg"])
        self._grid_frame.pack(expand=True)

        # Action buttons
        btn_row = tk.Frame(self, bg=t["bg"])
        btn_row.pack(pady=10)
        RetroButton(btn_row, self.app, "HINT",     command=self._hint).pack(side="left", padx=6)
        RetroButton(btn_row, self.app, "VALIDATE", command=self._validate).pack(side="left", padx=6)
        RetroButton(btn_row, self.app, "SUBMIT",   command=self._submit).pack(side="left", padx=6)
        RetroButton(btn_row, self.app, "CLEAR",    command=self._clear).pack(side="left", padx=6)

        self._msg = tk.Label(self, text="", font=FONT_SMALL,
                             bg=t["bg"], fg=t["accent"])
        self._msg.pack(pady=4)

        # Number pad
        pad = tk.Frame(self, bg=t["bg"])
        pad.pack(pady=(0, 12))
        for n in range(1, 10):
            tk.Button(pad, text=str(n), font=FONT_BTN, width=3,
                      bg=t["entry_bg"], fg=t["text"],
                      activebackground=t["accent2"], relief="flat", cursor="hand2",
                      command=lambda v=n: self._enter(v)).pack(side="left", padx=2)
        tk.Button(pad, text="⌫", font=FONT_BTN, width=3,
                  bg=t["entry_bg"], fg=t["accent"],
                  activebackground=t["accent2"], relief="flat", cursor="hand2",
                  command=lambda: self._enter(0)).pack(side="left", padx=2)

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._cells = []
        self._build()
        if self._puzzle:
            self.load_puzzle(self._puzzle["id"])

    # ── public ────────────────────────────────────────────────────────────────

    def load_puzzle(self, puzzle_id: int) -> None:
        # server returns {"status": "ok", "puzzle": {..., "initial_grid": ..., "solution_grid": ...}}
        result = self.app.server.get_puzzle(puzzle_id)
        if result.get("status") != "ok":
            self._msg.config(text="Could not load puzzle.")
            return

        self._puzzle      = result["puzzle"]
        self._selected    = None
        initial: str      = self._puzzle["initial_grid"]
        self._given       = [ch != "0" for ch in initial]
        self._user_values = [int(ch) for ch in initial]

        self._title_label.config(text=f"Puzzle #{puzzle_id}")
        self._msg.config(text="")
        self._draw_grid(9)          # all puzzles are 9×9 for now
        self._refresh_cells()
        self._start_timer()

    # ── grid ──────────────────────────────────────────────────────────────────

    def _draw_grid(self, size: int) -> None:
        for w in self._grid_frame.winfo_children():
            w.destroy()
        self._cells = []
        t   = self.app.theme
        box = int(size ** 0.5)

        for idx in range(size * size):
            r, c = divmod(idx, size)
            cell = tk.Label(
                self._grid_frame,
                text="", font=FONT_CELL, width=2, height=1,
                bg=t["entry_bg"], fg=t["text"], relief="flat", bd=0,
            )
            cell.grid(
                row=r, column=c,
                padx=(3 if c % box == 0 else 1, 3 if c == size - 1 else 0),
                pady=(3 if r % box == 0 else 1, 3 if r == size - 1 else 0),
                ipadx=4, ipady=4,
            )
            cell.bind("<Button-1>", lambda e, i=idx: self._select(i))
            self._cells.append(cell)

        self.bind_all("<Key>", self._on_key)

    def _refresh_cells(self) -> None:
        t = self.app.theme
        for idx, cell in enumerate(self._cells):
            val     = self._user_values[idx]
            is_given = self._given[idx]
            bg = t["bg_secondary"] if idx == self._selected else t["entry_bg"]
            cell.config(
                text=str(val) if val != 0 else "",
                bg=bg,
                fg=_GIVEN_FG if is_given else _USER_FG,
            )

    def _select(self, idx: int) -> None:
        if not self._given[idx]:
            self._selected = idx
        else:
            self._selected = None
        self._refresh_cells()

    # ── input ─────────────────────────────────────────────────────────────────

    def _enter(self, value: int) -> None:
        if self._selected is None:
            return
        self._user_values[self._selected] = value
        self._refresh_cells()

    def _on_key(self, event: tk.Event) -> None:
        if event.char.isdigit():
            self._enter(int(event.char))
        elif event.keysym == "BackSpace":
            self._enter(0)

    # ── timer ─────────────────────────────────────────────────────────────────

    def _start_timer(self) -> None:
        if self._timer_id:
            self.after_cancel(self._timer_id)
        self._start_time = time.monotonic()
        self._tick()

    def _tick(self) -> None:
        elapsed = int(time.monotonic() - self._start_time)
        m, s    = divmod(elapsed, 60)
        self._timer_label.config(text=f"{m:02d}:{s:02d}")
        self._timer_id = self.after(1000, self._tick)

    def _stop_timer(self) -> int:
        elapsed = int(time.monotonic() - self._start_time)
        if self._timer_id:
            self.after_cancel(self._timer_id)
            self._timer_id = None
        return elapsed

    # ── actions ───────────────────────────────────────────────────────────────

    def _hint(self) -> None:
        if not self._puzzle or self._selected is None:
            self._msg.config(text="Select an empty cell first.")
            return
        grid_str = "".join(str(v) for v in self._user_values)
        # server /hint expects {"puzzle_id", "current_grid"}
        # returns {"status": "ok", "row": r, "col": c, "value": v}
        result = self.app.server.get_hint(self._puzzle["id"], grid_str)
        if result.get("status") == "ok":
            r, c, v = result["row"], result["col"], result["value"]
            idx = r * 9 + c
            self._user_values[idx] = v
            self._refresh_cells()
            self._cells[idx].config(fg=_HINT_FG)
            self._msg.config(text=f"Hint: row {r}, col {c} = {v}",
                             fg=self.app.theme["accent2"])
        else:
            self._msg.config(text=result.get("message", "No hint available."))

    def _validate(self) -> None:
        if not self._puzzle:
            return
        solution: str = self._puzzle["solution_grid"]
        grid_str: str = "".join(str(v) for v in self._user_values)
        t = self.app.theme

        # Reset backgrounds
        for idx, cell in enumerate(self._cells):
            cell.config(bg=t["bg_secondary"] if idx == self._selected else t["entry_bg"])

        errors = []
        for i, (u, s) in enumerate(zip(grid_str, solution)):
            if u != "0" and u != s:
                errors.append(i)
                self._cells[i].config(bg=_ERROR_BG)

        if errors:
            self._msg.config(text=f"{len(errors)} incorrect cell(s) highlighted.",
                             fg=t["accent"])
        else:
            self._msg.config(text="All filled cells are correct! ✓", fg=t["accent2"])

    def _submit(self) -> None:
        if not self._puzzle:
            return
        if 0 in self._user_values:
            self._msg.config(text="Fill all cells before submitting.")
            return

        grid_str = "".join(str(v) for v in self._user_values)
        elapsed  = self._stop_timer()

        # server /solve expects {"user_id", "puzzle_id", "current_grid", "time_taken"}
        result = self.app.server.submit_solve(
            self._puzzle["id"], grid_str, elapsed
        )
        if result.get("status") == "ok":
            m, s = divmod(elapsed, 60)
            self._msg.config(text=f"Solved in {m:02d}:{s:02d}! 🎉",
                             fg=self.app.theme["accent2"])
        else:
            self._msg.config(text=result.get("message", "Incorrect solution."))
            self._start_timer()   # restart timer so they can keep trying

    def _clear(self) -> None:
        self._refresh_cells()
        self._msg.config(text="")

    def _back(self) -> None:
        self._stop_timer()
        self.app.show_frame("LobbyScreen")
