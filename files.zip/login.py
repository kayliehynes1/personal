# screens/login.py

import tkinter as tk
from typing import TYPE_CHECKING

from base import BaseScreen, RetroButton, RetroEntry
from theme import FONT_TITLE, FONT_BODY, FONT_SMALL

if TYPE_CHECKING:
    from client import App


class LoginScreen(BaseScreen):
    """Login screen — username + password, leads to LobbyScreen on success."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        wrapper = tk.Frame(self, bg=t["bg"])
        wrapper.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(wrapper, text="SUDOKU", font=FONT_TITLE,
                 bg=t["bg"], fg=t["accent"]).pack(pady=(0, 30))

        tk.Label(wrapper, text="Username", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).pack(anchor="w")
        self._username = RetroEntry(wrapper, self.app, width=28)
        self._username.pack(pady=(0, 12))

        tk.Label(wrapper, text="Password", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).pack(anchor="w")
        self._password = RetroEntry(wrapper, self.app, width=28, show="•")
        self._password.pack(pady=(0, 20))

        self._msg = tk.Label(wrapper, text="", font=FONT_SMALL,
                             bg=t["bg"], fg=t["accent"])
        self._msg.pack(pady=(0, 8))

        RetroButton(wrapper, self.app, "LOG IN",
                    command=self._on_login).pack(fill="x", pady=(0, 8))
        RetroButton(wrapper, self.app, "REGISTER",
                    command=lambda: self.app.show_frame("RegisterScreen")).pack(fill="x")

        tk.Button(self, text="☀ / ☾", font=FONT_SMALL, relief="flat",
                  bg=t["bg"], fg=t["text_dim"], cursor="hand2",
                  command=self.app.toggle_theme).place(relx=1.0, rely=0.0,
                                                       anchor="ne", x=-10, y=10)

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._build()

    def _on_login(self) -> None:
        username = self._username.get().strip()
        password = self._password.get()

        if not username or not password:
            self._msg.config(text="Please enter username and password.")
            return

        result = self.app.server.login(username, password)

        # server returns {"status": "ok", "user_id": ..., "username": ...}
        if result.get("status") == "ok":
            self.app.set_user(result["user_id"], result["username"])
            self._msg.config(text="")
            self._password.delete(0, "end")
            self.app.show_frame("LobbyScreen")
        else:
            self._msg.config(text=result.get("message", "Login failed."))
