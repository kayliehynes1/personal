# screens/register.py

import tkinter as tk
from typing import TYPE_CHECKING

from base import BaseScreen, RetroButton, RetroEntry
from theme import FONT_TITLE, FONT_BODY, FONT_SMALL

if TYPE_CHECKING:
    from client import App


class RegisterScreen(BaseScreen):
    """New account screen."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        wrapper = tk.Frame(self, bg=t["bg"])
        wrapper.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(wrapper, text="REGISTER", font=FONT_TITLE,
                 bg=t["bg"], fg=t["accent"]).pack(pady=(0, 30))

        tk.Label(wrapper, text="Username", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).pack(anchor="w")
        self._username = RetroEntry(wrapper, self.app, width=28)
        self._username.pack(pady=(0, 12))

        tk.Label(wrapper, text="Password", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).pack(anchor="w")
        self._password = RetroEntry(wrapper, self.app, width=28, show="•")
        self._password.pack(pady=(0, 12))

        tk.Label(wrapper, text="Confirm Password", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).pack(anchor="w")
        self._confirm = RetroEntry(wrapper, self.app, width=28, show="•")
        self._confirm.pack(pady=(0, 20))

        self._msg = tk.Label(wrapper, text="", font=FONT_SMALL,
                             bg=t["bg"], fg=t["accent"])
        self._msg.pack(pady=(0, 8))

        RetroButton(wrapper, self.app, "CREATE ACCOUNT",
                    command=self._on_register).pack(fill="x", pady=(0, 8))
        RetroButton(wrapper, self.app, "← BACK TO LOGIN",
                    command=lambda: self.app.show_frame("LoginScreen")).pack(fill="x")

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._build()

    def _on_register(self) -> None:
        username = self._username.get().strip()
        password = self._password.get()
        confirm  = self._confirm.get()

        if not username or not password:
            self._msg.config(text="All fields are required.")
            return
        if password != confirm:
            self._msg.config(text="Passwords do not match.")
            return
        if len(password) < 4:
            self._msg.config(text="Password must be at least 4 characters.")
            return

        result = self.app.server.register(username, password)

        # server returns {"status": "ok", "message": "User registered"}
        if result.get("status") == "ok":
            self._msg.config(
                text="Account created! Please log in.",
                fg=self.app.theme["accent2"],
            )
            self._username.delete(0, "end")
            self._password.delete(0, "end")
            self._confirm.delete(0, "end")
            self.after(1200, lambda: self.app.show_frame("LoginScreen"))
        else:
            self._msg.config(
                text=result.get("message", "Registration failed."),
                fg=self.app.theme["accent"],
            )
