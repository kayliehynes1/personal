# screens/add_puzzle.py

import tkinter as tk
from typing import TYPE_CHECKING

from base import BaseScreen, RetroButton, RetroEntry
from theme import FONT_HEADER, FONT_BODY, FONT_SMALL

if TYPE_CHECKING:
    from client import App

DIFFICULTIES = ["easy", "medium", "hard"]


class AddPuzzleScreen(BaseScreen):
    """Form for submitting a new puzzle — initial grid + solution as digit strings."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        bar = tk.Frame(self, bg=t["bg_secondary"], pady=8)
        bar.pack(fill="x")
        RetroButton(bar, self.app, "← LOBBY",
                    command=lambda: self.app.show_frame("LobbyScreen")).pack(side="left", padx=10)
        tk.Label(bar, text="ADD PUZZLE", font=FONT_HEADER,
                 bg=t["bg_secondary"], fg=t["text"]).pack(side="left", padx=16)

        wrapper = tk.Frame(self, bg=t["bg"])
        wrapper.pack(expand=True, fill="both", padx=40, pady=20)

        # Difficulty
        tk.Label(wrapper, text="Difficulty", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).grid(row=0, column=0, sticky="w", pady=6)
        self._diff_var = tk.StringVar(value="medium")
        diff_frame = tk.Frame(wrapper, bg=t["bg"])
        diff_frame.grid(row=0, column=1, sticky="w", padx=8)
        for d in DIFFICULTIES:
            tk.Radiobutton(diff_frame, text=d.capitalize(), variable=self._diff_var,
                           value=d, font=FONT_SMALL, bg=t["bg"], fg=t["text"],
                           selectcolor=t["bg_secondary"],
                           activebackground=t["bg"]).pack(side="left", padx=6)

        # Initial grid
        tk.Label(wrapper, text="Initial grid\n(0 = empty)", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).grid(row=1, column=0, sticky="nw", pady=6)
        self._initial_text = tk.Text(wrapper, font=FONT_SMALL, width=42, height=4,
                                     bg=t["entry_bg"], fg=t["entry_fg"],
                                     insertbackground=t["text"], relief="flat", bd=4)
        self._initial_text.grid(row=1, column=1, sticky="w", pady=6, padx=8)

        # Solution grid
        tk.Label(wrapper, text="Solution grid", font=FONT_BODY,
                 bg=t["bg"], fg=t["text_dim"]).grid(row=2, column=0, sticky="nw", pady=6)
        self._solution_text = tk.Text(wrapper, font=FONT_SMALL, width=42, height=4,
                                      bg=t["entry_bg"], fg=t["entry_fg"],
                                      insertbackground=t["text"], relief="flat", bd=4)
        self._solution_text.grid(row=2, column=1, sticky="w", pady=6, padx=8)

        self._msg = tk.Label(wrapper, text="", font=FONT_SMALL, bg=t["bg"],
                             fg=t["accent"], wraplength=480, justify="left")
        self._msg.grid(row=3, column=0, columnspan=2, sticky="w", pady=8)

        RetroButton(wrapper, self.app, "SUBMIT PUZZLE",
                    command=self._submit).grid(row=4, column=1, sticky="w", padx=8)

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._build()

    def _submit(self) -> None:
        initial  = "".join(self._initial_text.get("1.0", "end").split())
        solution = "".join(self._solution_text.get("1.0", "end").split())
        diff     = self._diff_var.get()

        if len(initial) != 81:
            self._msg.config(text=f"Initial grid must be 81 digits (got {len(initial)}).")
            return
        if len(solution) != 81:
            self._msg.config(text=f"Solution grid must be 81 digits (got {len(solution)}).")
            return
        if not initial.isdigit() or not solution.isdigit():
            self._msg.config(text="Grids must contain digits only.")
            return

        # server /puzzle expects {"user_id", "initial_grid", "solution_grid", "difficulty"}
        # validation (uniqueness, correctness) is done server-side via sudoku_logic
        result = self.app.server.add_puzzle(initial, solution, diff)

        if result.get("status") == "ok":
            self._msg.config(text="Puzzle added successfully! ✓",
                             fg=self.app.theme["accent2"])
            self._initial_text.delete("1.0", "end")
            self._solution_text.delete("1.0", "end")
        else:
            self._msg.config(text=result.get("message", "Failed to add puzzle."),
                             fg=self.app.theme["accent"])
