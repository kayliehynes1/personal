# screens/stats.py

import tkinter as tk
from typing import TYPE_CHECKING

from base import BaseScreen, RetroButton
from theme import FONT_HEADER, FONT_BODY, FONT_SMALL

if TYPE_CHECKING:
    from client import App


def _fmt(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    m, s = divmod(int(seconds), 60)
    return f"{m:02d}:{s:02d}"


class StatsScreen(BaseScreen):
    """Personal statistics for the logged-in user."""

    def __init__(self, parent: tk.Widget, app: "App") -> None:
        super().__init__(parent, app)
        self._build()

    def _build(self) -> None:
        t = self.app.theme
        self.config(bg=t["bg"])

        bar = tk.Frame(self, bg=t["bg_secondary"], pady=8)
        bar.pack(fill="x")
        RetroButton(bar, self.app, "← LOBBY",
                    command=lambda: self.app.show_frame("LobbyScreen")).pack(side="left", padx=10)
        tk.Label(bar, text="MY STATS", font=FONT_HEADER,
                 bg=t["bg_secondary"], fg=t["text"]).pack(side="left", padx=16)
        RetroButton(bar, self.app, "↺ REFRESH",
                    command=self._load).pack(side="right", padx=10)

        self._content = tk.Frame(self, bg=t["bg"])
        self._content.pack(expand=True)

    def apply_theme(self) -> None:
        for w in self.winfo_children():
            w.destroy()
        self._build()
        self._load()

    def tkraise(self, *args) -> None:  # type: ignore[override]
        super().tkraise(*args)
        self._load()

    def _load(self) -> None:
        for w in self._content.winfo_children():
            w.destroy()
        t = self.app.theme

        # server GET /user_stats/<user_id> returns {"status": "ok", "stats": {...}}
        result = self.app.server.get_user_stats()
        if result.get("status") != "ok":
            tk.Label(self._content, text="Could not load stats.",
                     font=FONT_BODY, bg=t["bg"], fg=t["accent"]).pack(pady=40)
            return

        stats = result["stats"]
        rows  = [
            ("Player",          stats.get("username", "—")),
            ("Puzzles solved",  str(stats.get("puzzles_solved", 0))),
            ("Puzzles posted",  str(stats.get("puzzles_posted", 0))),
            ("Best solve time", _fmt(stats.get("best_time"))),
            ("Avg solve time",  _fmt(stats.get("avg_time"))),
        ]

        for label, value in rows:
            row = tk.Frame(self._content, bg=t["bg_secondary"], pady=6, padx=20)
            row.pack(fill="x", pady=3, padx=60)
            tk.Label(row, text=label, font=FONT_BODY, width=20, anchor="w",
                     bg=t["bg_secondary"], fg=t["text_dim"]).pack(side="left")
            tk.Label(row, text=value, font=FONT_BODY, anchor="w",
                     bg=t["bg_secondary"], fg=t["text"]).pack(side="left")
