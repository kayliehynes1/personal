# screens/__init__.py
from screens.login       import LoginScreen
from screens.register    import RegisterScreen
from screens.lobby       import LobbyScreen
from screens.puzzle      import PuzzleScreen
from screens.add_puzzle  import AddPuzzleScreen
from screens.stats       import StatsScreen
from screens.leaderboard import LeaderboardScreen
from screens.social      import SocialScreen

__all__ = [
    "LoginScreen", "RegisterScreen", "LobbyScreen",
    "PuzzleScreen", "AddPuzzleScreen", "StatsScreen",
    "LeaderboardScreen", "SocialScreen",
]
